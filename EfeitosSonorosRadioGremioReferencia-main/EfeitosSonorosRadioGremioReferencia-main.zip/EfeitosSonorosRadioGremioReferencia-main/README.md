# Efeitos Sonoros da Rádio Grêmio Estudantil
<p align="center">Baseado no projeto Alura MIDI do curso: <a href="cursos.alura.com.br/course/javascript-web-crie-paginas-dinamicas">JavaScript para Web: Crie páginas dinâmicas</a></p>

## Screenshots
![print do projeto no navegador](https://github.com/silviosnjr/EfeitosSonorosRadioGremioReferencia/blob/main/print_efeitos_sonoros_radio_gremio_estudantil.png)

## Tecnologias
* HTML
* CSS
* JavaScript
